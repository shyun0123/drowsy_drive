package org.techtown.login_register;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Switch;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DriveStart extends AppCompatActivity {

    private Button btn_stop;
    private Switch mswitch;
    private ProgressBar progressBar;
    private CountDownTimer countDownTimer;
    Intent receivedIntent = getIntent();
    private Button btn_music;
    private MediaPlayer mediaPlayer;
    private String selectedAudio, userID; // 선택한 알람음에 대한 정보를 저장
    private static final String PREFS_NAME = "AlarmPrefs"; // SharedPreferences 이름

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drive_start);

        String userID = receivedIntent.getStringExtra("userID");
        String userPass = receivedIntent.getStringExtra("userPass");

        Thread mthread = new Thread(() -> {
            Connection connection = DatabaseConnector.connect();
            try {
                if (connection != null) {
                    System.out.println("성공");
                    LocalDateTime currentTime = LocalDateTime.now();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                    String formattedTime = currentTime.format(formatter);

                    String query = "INSERT INTO drive_info (user_id, start_time) VALUES (?, ?)";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, userID);
                    preparedStatement.setString(2, formattedTime);
                    preparedStatement.executeUpdate();
                    connection.close();

                } else {
                    System.out.println("실패");
                    connection.close();
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });

        mthread.start();


        // 이전 액티비티에서 전달된 선택한 알람음 정보를 가져옴
        Intent intent = getIntent();
        if (intent.hasExtra("userID")) {

            // Set the userID to the TextView
        }
        if (intent != null) {
            selectedAudio = intent.getStringExtra("selectedAudio");
        }

        // SharedPreferences에서 저장된 알람음을 가져와 설정
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        selectedAudio = preferences.getString("selectedAudio", "기본 알람음 (전자 알람)");

        btn_stop = findViewById(R.id.btn_stop);
        btn_music = findViewById(R.id.btn_music);

        // 선택한 알람음에 따라 MediaPlayer를 설정
        if (selectedAudio != null) {
            if (selectedAudio.equals("기본 알람음 (기상 나팔)")) {
                mediaPlayer = MediaPlayer.create(this, R.raw.basic1);
            } else if (selectedAudio.equals("기본 알람음 (전자 알람)")) {
                mediaPlayer = MediaPlayer.create(this, R.raw.basic2);
            } else if (selectedAudio.equals("기본 알람음 (아날로그 알람)")) {
                mediaPlayer = MediaPlayer.create(this, R.raw.basic3);
            } else {
                // 선택한 알람음이 사용자가 추가한 경우, 해당 파일을 재생합니다.
                Uri selectedFileUri = Uri.fromFile(new File(getFilesDir(), selectedAudio));
                mediaPlayer = MediaPlayer.create(this, selectedFileUri);
            }
        } else {
            mediaPlayer = MediaPlayer.create(this, R.raw.basic1);
        }

        // 음악을 반복 재생하도록 설정
        mediaPlayer.setLooping(true);

        btn_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                Intent intent = new Intent(DriveStart.this, MainMenu.class);
                intent.putExtra("userID", userID);
                startActivity(intent);
                finish();
            }
        });

        btn_music.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mediaPlayer != null) {
                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.pause();
                        btn_music.setText("Play Music");
                    } else {
                        mediaPlayer.start();
                        btn_music.setText("Pause Music");
                    }
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
    }
}
