package org.techtown.login_register;

import android.util.Log;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.SQLException;

public class DatabaseConnector {
    //private static final String DB_URL = "jdbc:mysql:drowsy-drive-project.czwprr6kyrdh.ap-northeast-2.rds.amazonaws.com:3306/drowsy_drive";
    private static final String DB_URL = "jdbc:mysql://drowsy-drive-project.czwprr6kyrdh.ap-northeast-2.rds.amazonaws.com:3306/drowsy_drive";
    private static final String USER = "shyun";
    private static final String PASS = "drowsy02!";

    public static Connection connect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (ClassNotFoundException | SQLException e) {
            Log.e("DatabaseConnector", "Exception: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}