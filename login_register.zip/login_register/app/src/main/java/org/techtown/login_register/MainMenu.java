package org.techtown.login_register;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.SQLException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.pedro.library.AutoPermissions;
import com.pedro.library.AutoPermissionsListener;

import java.sql.Connection;

public class MainMenu extends AppCompatActivity {
    private Button btn_logout, btn_id;
    private ImageButton ibtn_start, ibtn_info,ibtn_alarm,ibtn_record;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        Intent receivedIntent = getIntent();
        String userID = receivedIntent.getStringExtra("userID");
        String userPass = receivedIntent.getStringExtra("userPass");

        new Thread(() -> {
            try {
                Connection connection = DatabaseConnector.connect();
                if (connection != null)
                {
                    System.out.println("성공");
                }
                else {
                    System.out.println("실패");
                }
            }catch(SQLException e)
            {
                e.printStackTrace();
            }
        }
        ).start();

        btn_logout = findViewById(R.id.btn_logout);
        ibtn_start = findViewById(R.id.ibtn_start);
        ibtn_info = findViewById(R.id.ibtn_info);
        ibtn_alarm = findViewById(R.id.ibtn_alarm);
        ibtn_record = findViewById(R.id.ibtn_record);
        btn_id = findViewById(R.id.btn_id);

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainMenu.this, loginactivity.class);
                startActivity(intent);
                finish();
            }
        });

        btn_id.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainMenu.this);
                builder.setTitle("아이디");
                builder.setMessage(String.format("아이디 : %s\n비밀번호 : %s", userID, userPass));
                builder.setPositiveButton("확인", null);
                builder.create().show();
            }
        });

        ibtn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainMenu.this, DriveStart.class);
                intent.putExtra("userID", userID);
                intent.putExtra("userPass", userPass);
                startActivity(intent);
            }
        });

        ibtn_alarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainMenu.this, AlarmOption.class);
                startActivity(intent);
            }
        });

        ibtn_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainMenu.this, DriveInfo.class);
                intent.putExtra("userID", userID);
                intent.putExtra("userPass", userPass);
                startActivity(intent);
            }
        });

        ibtn_record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainMenu.this, DriveRecord.class);
                intent.putExtra("userID", userID);
                intent.putExtra("userPass", userPass);
                startActivity(intent);
            }
        });
    }

    private double waitTime = 0;
    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        if (System.currentTimeMillis() - waitTime >= 1500) {
            waitTime = System.currentTimeMillis();
            Toast.makeText(this, "뒤로가기 버튼을 한번 더 누르면 종료됩니다.", Toast.LENGTH_SHORT).show();
        } else {
            finish(); // 액티비티 종료
        }
    }
}