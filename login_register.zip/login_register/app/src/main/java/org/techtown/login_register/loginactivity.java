package org.techtown.login_register;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class loginactivity extends AppCompatActivity {

    private EditText et_id, et_pass;
    private Button btn_login, btn_register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginactivity);

        et_id = findViewById(R.id.et_id);
        et_pass = findViewById(R.id.et_pass);

        btn_login = findViewById(R.id.btn_login);
        btn_register = findViewById(R.id.btn_register);

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(loginactivity.this, register_activity.class);
                startActivity(intent);
            }
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userID = et_id.getText().toString();
                String userPass = et_pass.getText().toString();

                // 백그라운드 스레드에서 데이터베이스 연결 시도
                new ConnectToDatabaseTask().execute(userID, userPass);
            }
        });
    }

    private class ConnectToDatabaseTask extends AsyncTask<String, Void, Connection> {
        @Override
        protected Connection doInBackground(String... params) {
            String userID = params[0];
            String userPass = params[1];

            try {
                Connection connection = DatabaseConnector.connect();
                if (connection != null) {
                    // 데이터베이스 쿼리
                    String query = "SELECT * FROM user_info WHERE user_id = ? AND user_pw = ?";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, userID);
                    preparedStatement.setString(2, userPass);
                    ResultSet resultSet = preparedStatement.executeQuery();

                    if (resultSet.next()) {
                        // 로그인 성공
                        return connection;
                    } else {
                        // 로그인 실패
                        connection.close();
                        return null;
                    }
                } else {
                    // 데이터베이스 연결 실패
                    return null;
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(Connection connection) {
            if (connection != null) {
                // 로그인 성공
                Toast.makeText(getApplicationContext(), "로그인 성공", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(loginactivity.this, MainMenu.class);
                intent.putExtra("userID", et_id.getText().toString());
                intent.putExtra("userPass", et_pass.getText().toString());
                startActivity(intent);
                finish();
            } else {
                // 로그인 실패
                Toast.makeText(getApplicationContext(), "로그인 실패", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

