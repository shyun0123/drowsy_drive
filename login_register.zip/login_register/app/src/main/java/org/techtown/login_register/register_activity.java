package org.techtown.login_register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class register_activity extends AppCompatActivity {

    private EditText et_id, et_pass, et_pass2, et_name, et_phone;
    private Button btn_register, btn_back, btn_ok;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        et_id = findViewById(R.id.et_id);
        et_pass = findViewById(R.id.et_pass);
        et_pass2 = findViewById(R.id.et_pass2);
        et_name = findViewById(R.id.et_name);
        et_phone = findViewById(R.id.et_phone);

        btn_register = findViewById(R.id.btn_register);
        btn_back = findViewById(R.id.btn_back);
        btn_ok = findViewById(R.id.btn_ok);

        // 이전으로 돌아가는 버튼
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(register_activity.this, loginactivity.class);
                startActivity(intent);
                finish();
            }
        });

        // 아이디 중복 확인 버튼
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // EditText에 입력된 아이디 가져오기
                String userID = et_id.getText().toString();

                // 백그라운드 스레드에서 데이터베이스 연결 시도
                new CheckDuplicateIDTask().execute(userID);
            }
        });

        // 회원가입 버튼
        // 회원가입 버튼
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // EditText에 입력된 값 가져오기
                String userID = et_id.getText().toString();
                String userPass = et_pass.getText().toString();
                String userPass2 = et_pass2.getText().toString();
                String userName = et_name.getText().toString();
                String userPhone = et_phone.getText().toString();

                // 빈칸 여부 확인
                if (userID.isEmpty() || userPass.isEmpty() || userPass2.isEmpty() || userName.isEmpty() || userPhone.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "빈칸을 모두 채워주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // 비밀번호 확인
                if (!userPass.equals(userPass2)) {
                    Toast.makeText(getApplicationContext(), "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // 백그라운드 스레드에서 회원가입 시도
                new RegisterUserTask().execute(userID, userPass, userName, userPhone);
            }
        });

    }

    private class CheckDuplicateIDTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            String userID = params[0];

            try {
                Connection connection = DatabaseConnector.connect();
                if (connection != null) {
                    String query = "SELECT * FROM user_info WHERE user_id = ?";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, userID);
                    ResultSet resultSet = preparedStatement.executeQuery();

                    if (resultSet.next()) {
                        // 중복된 아이디가 이미 존재하는 경우
                        return true;
                    } else {
                        // 중복되지 않는 아이디인 경우
                        return false;
                    }
                } else {
                    // 데이터베이스 연결 실패
                    return false;
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean isDuplicate) {
            if (isDuplicate) {
                // 중복된 아이디가 존재하는 경우
                Toast.makeText(getApplicationContext(), "이미 사용 중인 아이디입니다.", Toast.LENGTH_SHORT).show();
                btn_register.setEnabled(false); // 회원가입 버튼 비활성화
            } else {
                // 중복되지 않는 아이디인 경우
                Toast.makeText(getApplicationContext(), "사용 가능한 아이디입니다.", Toast.LENGTH_SHORT).show();
                btn_register.setEnabled(true); // 회원가입 버튼 활성화
            }
        }
    }

    private class RegisterUserTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            String userID = params[0];
            String userPass = params[1];
            String userName = params[2];
            String userPhone = params[3];

            try {
                Connection connection = DatabaseConnector.connect();
                if (connection != null) {
                    String query = "INSERT INTO user_info (user_id, user_pw, user_name, user_pn) VALUES (?, ?, ?, ?)";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, userID);
                    preparedStatement.setString(2, userPass);
                    preparedStatement.setString(3, userName);
                    preparedStatement.setString(4, userPhone);
                    int result = preparedStatement.executeUpdate();

                    if (result > 0) {
                        // 회원가입 성공
                        return true;
                    } else {
                        // 회원가입 실패
                        return false;
                    }
                } else {
                    // 데이터베이스 연결 실패
                    return false;
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean isRegistered) {
            if (isRegistered) {
                // 회원가입 성공
                Toast.makeText(getApplicationContext(), "회원가입 성공", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(register_activity.this, loginactivity.class);
                startActivity(intent);
                finish();
            } else {
                // 회원가입 실패
                Toast.makeText(getApplicationContext(), "회원가입 실패", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
