package org.techtown.login_register;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class DriveRecord extends AppCompatActivity {
    private TextView tv_id2, tv_score;
    private Button btn_back, btn_forward, btn_distance;
    private ImageButton ibtn_date;
    private EditText et_date;
    private Spinner sp_no;
    private String userID;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drive_record);

        tv_id2 = findViewById(R.id.tv_id2);
        tv_score = findViewById(R.id.tv_score);
        btn_back = findViewById(R.id.btn_back);
        btn_distance = findViewById(R.id.btn_distance);
        btn_forward = findViewById(R.id.btn_forward);
        ibtn_date = findViewById(R.id.ibtn_date);
        et_date = findViewById(R.id.et_date);
        sp_no = findViewById(R.id.sp_no);

        // Get the userID from the intent
        Intent intent = getIntent();
        if (intent.hasExtra("userID")) {
            userID = intent.getStringExtra("userID");
            // Set the userID to the TextView
            tv_id2.setText(userID);
        }

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DriveRecord.this, MainMenu.class);
                intent.putExtra("userID", userID);
                startActivity(intent);
                finish();
            }
        });

        ibtn_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userDate = et_date.getText().toString();
                new ConnectToDatabaseTask().execute(userDate);
            }
        });

        // Set up an OnItemSelectedListener for the Spinner
        sp_no.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedItem = sp_no.getSelectedItem().toString();

                // Extract the drive number from the selected item
                int driveNo = Integer.parseInt(selectedItem.split("\\[")[0]);

                // Fetch the forward vision and total distance for the selected drive record
                new FetchDriveInfoTask().execute(driveNo);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing when nothing is selected
            }
        });
    }

    private class ConnectToDatabaseTask extends AsyncTask<String, Void, List<String>> {
        @Override
        protected List<String> doInBackground(String... params) {
            String userDate = params[0];
            List<String> driveRecords = new ArrayList<>();

            try {
                Connection connection = DatabaseConnector.connect();
                if (connection != null) {
                    String query = "SELECT drive_no, start_time, end_time FROM drive_info WHERE user_id = ? AND DATE(start_time) = ?";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, userID);
                    preparedStatement.setString(2, userDate);

                    ResultSet resultSet = preparedStatement.executeQuery();

                    while (resultSet.next()) {
                        int driveNo = resultSet.getInt("drive_no");
                        String startTime = new SimpleDateFormat("HH:mm:ss").format(resultSet.getTimestamp("start_time"));
                        String endTime = new SimpleDateFormat("HH:mm:ss").format(resultSet.getTimestamp("end_time"));

                        // Add the drive record to the list
                        driveRecords.add(driveNo + "[" + startTime + "," + endTime + "]");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return driveRecords;
        }

        @Override
        protected void onPostExecute(List<String> driveRecords) {
            if (!driveRecords.isEmpty()) {
                // Display the drive records in the Spinner
                ArrayAdapter<String> adapter = new ArrayAdapter<>(DriveRecord.this, android.R.layout.simple_spinner_dropdown_item, driveRecords);
                sp_no.setAdapter(adapter);
            } else {
                // No matching records found in the database for the specific user and date
                Toast.makeText(getApplicationContext(), "운전 기록이 없습니다.", Toast.LENGTH_SHORT).show();
                sp_no.setAdapter(null); // Clear the Spinner
            }
        }
    }


    private class FetchDriveInfoTask extends AsyncTask<Integer, Void, DriveInfo> {
        @Override
        protected DriveInfo doInBackground(Integer... params) {
            int driveNo = params[0];

            try {
                Connection connection = DatabaseConnector.connect();
                if (connection != null) {
                    String query = "SELECT forward_vision, total_distance FROM drive_info WHERE drive_no = ?";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setInt(1, driveNo);

                    ResultSet resultSet = preparedStatement.executeQuery();

                    if (resultSet.next()) {
                        int forwardVision = resultSet.getInt("forward_vision");
                        int totalDistance = resultSet.getInt("total_distance");

                        return new DriveInfo(forwardVision, totalDistance);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(DriveInfo driveInfo) {
            if (driveInfo != null) {
                // Update btn_forward and btn_distance
                String forwardVisionText = driveInfo.getForwardVision() + "회";
                String totalDistanceText = driveInfo.getTotalDistance() + "m";

                btn_forward.setText(forwardVisionText);
                btn_distance.setText(totalDistanceText);

                // Calculate the score
                int forwardVision = driveInfo.getForwardVision();
                int totalDistance = driveInfo.getTotalDistance();
                int score = 100 - 2 * forwardVision - (int)(0.5 * totalDistance);

                // Update tv_score
                tv_score.setText(score + "점");
            }
        }
    }

    // Define a DriveInfo class to store forwardVision and totalDistance
    private static class DriveInfo {
        private final int forwardVision;
        private final int totalDistance;

        public DriveInfo(int forwardVision, int totalDistance) {
            this.forwardVision = forwardVision;
            this.totalDistance = totalDistance;
        }

        public int getForwardVision() {
            return forwardVision;
        }

        public int getTotalDistance() {
            return totalDistance;
        }
    }
}

